![Header Image](https://cdn.discordapp.com/attachments/826689002697654273/941264789508878346/Logo_Big.png)

# Bret's Building Utilities
## Resource/Data Pack for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)

[Note: Check branches to find resource/datapack]

This data/resourcepack is a smart tool used to make building with custom models easier!
