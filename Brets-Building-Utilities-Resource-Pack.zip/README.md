![Header Image](https://cdn.discordapp.com/attachments/826689002697654273/941264789508878346/Logo_Big.png)

# Bret's Building Utilities
## Resource/Data Pack for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)

[Note: Check branches to find resource/datapack]

This data/resourcepack is a smart tool used to make building with custom models easier!
![2022-04-24_12 09 42](https://user-images.githubusercontent.com/26262092/165000066-cb587c5e-4f79-4536-9969-b81d977a53b3.png)
![bbb_preview6](https://user-images.githubusercontent.com/26262092/165000071-36b986ac-9b33-490b-a1bb-40903c5d67e9.png)
![bbb_preview5](https://user-images.githubusercontent.com/26262092/165000072-3172eaac-8318-4100-acf1-c81e29b092d1.png)
![bbb_preview4](https://user-images.githubusercontent.com/26262092/165000073-b45825a1-79ff-4074-a6eb-d43088c549b8.png)
