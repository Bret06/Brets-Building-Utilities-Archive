![Header Image](https://cdn.discordapp.com/attachments/826689002697654273/941264789508878346/Logo_Big.png)

# Bret's Building Utilities
## Resource/Data Pack for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)

[Note: Check branches to find resource/datapack]

:information_source: Bret's Building Utilities has been moved! (https://github.com/LunarEclipseStudios/Architects-Toolbox)

This data/resourcepack is a smart tool used to make building with custom models easier!
![2022-04-24_12 09 42](https://user-images.githubusercontent.com/26262092/165000009-fb30cef2-c4d2-47a3-ad37-fe5e4602cc02.png)
![bbb_preview6](https://user-images.githubusercontent.com/26262092/165000025-05344623-58e2-4747-952d-645a8a013480.png)
![bbb_preview5](https://user-images.githubusercontent.com/26262092/165000028-3994acd1-1965-4217-a3d1-54c601168d5d.png)
![bbb_preview4](https://user-images.githubusercontent.com/26262092/165000030-3b4b5d4a-2a0e-4512-9065-18907a4615d1.png)
