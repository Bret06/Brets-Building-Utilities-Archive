![Header Image](https://cdn.discordapp.com/attachments/826689002697654273/941264789508878346/Logo_Big.png)

# Bret's Building Utilities
## Resource/Data Pack for Minecraft: Java Edition

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-brightgreen.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)

[Note: Check branches to find resource/datapack]

This data/resourcepack is a smart tool used to make building with custom models easier!
![2022-04-24_12 09 42](https://user-images.githubusercontent.com/26262092/165000045-7dffac57-e380-4511-928b-5c80793f89fb.png)
![bbb_preview6](https://user-images.githubusercontent.com/26262092/165000046-fd9e9022-6528-4564-b6f0-7d99f5b701a9.png)
![bbb_preview5](https://user-images.githubusercontent.com/26262092/165000048-1210d2f6-aaf2-46be-800e-1cf1cae65ce7.png)
![bbb_preview4](https://user-images.githubusercontent.com/26262092/165000051-62d5b858-9130-4d5e-bbb7-cbe1b809098a.png)
